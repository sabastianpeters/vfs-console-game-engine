RUNESOLE: A Console C# Adventure

Created by Sabastian Peters and Yuya Yoshino, inspired by Unity and Runescape.

Github:
    https://github.com/sabastianpeters/VFS-Term1-CSharp-Assignment3/tree/release/submit


IMPROVEMENT NOTES:

No sound or physics, and many untility methods are missing from classes. We only created what we needed.

In an ideal situtation, the engine would be compiled in a seperate assembly from the game classes. This would allow for the use of "internal" on Engine only methods and members that are required to be public. This would further improve ease of creation. This was an oversight during creation and not enough time to do this by the end of project.